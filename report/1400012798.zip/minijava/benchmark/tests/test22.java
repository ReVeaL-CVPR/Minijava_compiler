class test22{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	int[] op;
	Test test;

	op = new int[10];

	op[test] = 20;		// TE

	return 0;
    }
}
