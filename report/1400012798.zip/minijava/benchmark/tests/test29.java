class test29{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	Test test;
	int op;

	test = new op();	// TE TE

	return 0;
    }
}
