class test31{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	int[] op;

	op = new int[true];	// TE

	return 0;
    }
}
