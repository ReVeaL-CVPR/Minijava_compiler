class test34{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	System.out.println(true);	// TE

	return 0;
    }
}
