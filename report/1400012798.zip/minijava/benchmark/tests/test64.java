class test64{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	i = 10;	// TE

	return 0;
    }
}
