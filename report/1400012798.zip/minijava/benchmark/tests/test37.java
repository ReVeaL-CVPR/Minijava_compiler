class test37{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	while (1) System.out.println(1);	// TE

	return 0;
    }
}
