class test19{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{
	
    public int start(){

	int[] op;

	op = new int[10];

	op = 5;		// TE

	return 0;
    }
}
