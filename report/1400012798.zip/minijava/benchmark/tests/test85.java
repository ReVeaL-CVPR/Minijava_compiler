class test85{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test {

    Test test;
    int i;

    public int start(){

	i = test.next(test, 45, true);
	
	return 0;
    }

    public int next(Test t, int j, boolean b){

	return 0;
    }

}
