class test43{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{
	
    public int start(){

	boolean op;

	op[10] = 5;	// TE

	return 0;
    }
}
