class test16{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{
	
    public int start(){
		
	System.out.println(op);	// TE TE

	return 0;
    }
}
