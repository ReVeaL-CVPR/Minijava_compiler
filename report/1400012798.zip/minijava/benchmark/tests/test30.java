class test30{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test{

    public int start(){

	Test test;

	test = new test();	// TE TE

	return 0;
    }
}
