class test83{
    public static void main(String[] a){
	System.out.println(new Test().start());
    }
}

class Test {

    Test test;
    int i;

    public int start(){

	i = test.next(5, 5);	// TE
	
	return 0;
    }

    public int next(int j){

	return 0;
    }

}
